import React from 'react';
import LoanCard from './LoanCard';

const SAMPLE_LOANS = [
  {
    amount: 5000,
    term: 12,
    interest: 8.5,
    borrower: 'Maria S.',
    country: 'Mexico',
    purpose: 'Small Business Expansion',
    creditScore: 720,
    funded: 3500,
  },
  {
    amount: 2000,
    term: 6,
    interest: 7.2,
    borrower: 'John D.',
    country: 'Kenya',
    purpose: 'Agriculture Equipment',
    creditScore: 680,
    funded: 1200,
  },
  {
    amount: 3500,
    term: 9,
    interest: 9.0,
    borrower: 'Sarah M.',
    country: 'India',
    purpose: 'Education Funding',
    creditScore: 700,
    funded: 2800,
  },
];

export default function LoanList() {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Featured Loan Opportunities</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse through our carefully curated selection of loan opportunities from around the world.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SAMPLE_LOANS.map((loan, index) => (
            <LoanCard key={index} {...loan} />
          ))}
        </div>
      </div>
    </section>
  );
}
import React from 'react';
import { Clock, TrendingUp, Users } from 'lucide-react';

interface LoanCardProps {
  amount: number;
  term: number;
  interest: number;
  borrower: string;
  country: string;
  purpose: string;
  creditScore: number;
  funded: number;
}

export default function LoanCard({
  amount,
  term,
  interest,
  borrower,
  country,
  purpose,
  creditScore,
  funded,
}: LoanCardProps) {
  const progress = (funded / amount) * 100;

  return (
    <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition p-6 border border-gray-100">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">${amount.toLocaleString()}</h3>
          <p className="text-sm text-gray-500">{purpose}</p>
        </div>
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
          {country}
        </span>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500 flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {term} months
          </span>
          <span className="text-gray-500 flex items-center gap-1">
            <TrendingUp className="h-4 w-4" />
            {interest}% APR
          </span>
          <span className="text-gray-500 flex items-center gap-1">
            <Users className="h-4 w-4" />
            {creditScore}
          </span>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Progress</span>
            <span className="text-gray-900 font-medium">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        <button className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition font-medium">
          Lend Now
        </button>
      </div>
    </div>
  );
}
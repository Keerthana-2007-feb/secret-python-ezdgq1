import React from 'react';
import { Globe } from 'lucide-react';

function Hero() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-blue-900 to-blue-700 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col items-center text-center">
          <Globe className="w-16 h-16 mb-8 text-blue-300" />
          <h1 className="text-5xl font-bold mb-6">Cross-Border Micro-Loans</h1>
          <p className="text-xl text-blue-200 max-w-2xl mb-12">
            Empowering global financial inclusion through blockchain technology and AI
          </p>
          <div className="flex gap-4">
            <button className="bg-white text-blue-900 px-8 py-3 rounded-full font-semibold hover:bg-blue-100 transition-colors">
              Get Started
            </button>
            <button className="border-2 border-white px-8 py-3 rounded-full font-semibold hover:bg-white/10 transition-colors">
              Learn More
            </button>
          </div>
        </div>
      </div>
      
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -right-1/2 w-full h-full bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-blue-400/20 rounded-full blur-3xl"></div>
      </div>
    </div>
  );
}

export default Hero;
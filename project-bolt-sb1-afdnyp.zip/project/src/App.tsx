import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import LoanList from './components/LoanList';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <LoanList />
    </div>
  );
}

export default App;